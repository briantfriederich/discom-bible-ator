from setuptools import setup

setup(name='discombibleator',
      version="1.95",
      packages = ['discombibleator'],
      include_package_data=True,
      author = "Brian Friederich",
      author_email = "briantfriederich@gmail.com",
      zip_safe=False)
