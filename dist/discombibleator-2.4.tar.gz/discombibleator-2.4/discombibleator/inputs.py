class Verse:
    def __init__(self, string, units = "imperial"):
        self.string = string
        self.units = units
