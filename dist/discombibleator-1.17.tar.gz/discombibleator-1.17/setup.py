from setuptools import setup

setup(name='discombibleator',
      version="1.17",
      packages = ['discombibleator'],
      author = "Brian Friederich",
      author_email = "briantfriederich@gmail.com",
      zip_safe=False)
