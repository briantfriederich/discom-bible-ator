from discombibleator.main import Discombibleator
from discombibleator.inputs import Verse
